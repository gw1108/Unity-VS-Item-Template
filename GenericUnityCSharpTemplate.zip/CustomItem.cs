﻿//$company$
//Date Created : $time$
//Created by : $username$

using System;
using UnityEngine;

namespace $rootnamespace$
{
	public class $safeitemname$ : MonoBehaviour
	{
	}
}